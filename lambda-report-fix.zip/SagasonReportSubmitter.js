import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand, UpdateCommand, ScanCommand } from "@aws-sdk/lib-dynamodb";
import { SESClient, SendEmailCommand, SendRawEmailCommand } from "@aws-sdk/client-ses";
import https from "https";

const dbClient = new DynamoDBClient({ region: "sa-east-1" });
const docClient = DynamoDBDocumentClient.from(dbClient);
const sesClient = new SESClient({ region: "sa-east-1" });

// ==========================================
// CONFIGURACIÓN DE TWILIO (WHATSAPP)
// ==========================================
const TWILIO_ACCOUNT_SID = process.env.TWILIO_ACCOUNT_SID; 
const TWILIO_AUTH_TOKEN = process.env.TWILIO_AUTH_TOKEN; 
const TWILIO_FROM_PHONE = process.env.TWILIO_FROM_PHONE || "whatsapp:+14155238886";
const MAPS_API_KEY = process.env.GOOGLE_MAPS_API_KEY || "";

export const handler = async (event) => {
    if (event.requestContext && event.requestContext.http && event.requestContext.http.method === "OPTIONS") {
        return { statusCode: 204, headers: { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "*", "Access-Control-Allow-Methods": "POST, OPTIONS" } };
    }

    const body = JSON.parse(event.body);
    const { tagId, name, phone, message, location, action, email, htmlContent } = body;

    // --- ACCIÓN: OBTENER ESTADÍSTICAS PÚBLICAS (DINÁMICO) ---
    if (action === "get_public_stats") {
        try {
            const res = await docClient.send(new ScanCommand({
                TableName: "SagasonTags",
                ProjectionExpression: "tagId, donated, #st, country",
                ExpressionAttributeNames: { "#st": "status" }
            }));

            const activeTags = res.Items.filter(item => item.status === "Activo");
            const donatedTags = activeTags.filter(item => item.donated === true);

            // Agrupar por país
            const countryStats = {};
            activeTags.forEach(tag => {
                const c = tag.country || "Chile";
                countryStats[c] = (countryStats[c] || 0) + 1;
            });

            return {
                statusCode: 200,
                headers: { "Access-Control-Allow-Origin": "*" },
                body: JSON.stringify({
                    total_active: activeTags.length,
                    total_donated: donatedTags.length,
                    countries: countryStats
                })
            };
        } catch (error) {
            console.error("Error stats:", error);
            return { statusCode: 500, headers: { "Access-Control-Allow-Origin": "*" }, body: JSON.stringify({ error: "Fallo fetch stats" }) };
        }
    }

    // Endpoint interno para respaldar lote de QRs generados con ZIP adjunto (Forzado al administrador)
    if (action === "backup_batch" && htmlContent) {
        const adminEmail = "brluson@gmail.com"; 
        try {
            if (body.zipBase64) {
                // Enviar correo RAW con adjunto ZIP MIME multiparte
                const boundary = "NextPart_" + Date.now().toString(16);
                let rawMessage = [
                    `From: Fábrica Sagason <no-reply@sagason.cl>`,
                    `To: ${adminEmail}`,
                    `Subject: Respaldo: Códigos QR Sagason Generados`,
                    `MIME-Version: 1.0`,
                    `Content-Type: multipart/mixed; boundary="${boundary}"`,
                    ``,
                    `--${boundary}`,
                    `Content-Type: text/html; charset=UTF-8`,
                    ``,
                    htmlContent,
                    ``,
                    `--${boundary}`,
                    `Content-Type: application/zip; name="${body.zipName || 'SagasonLote.zip'}"`,
                    `Content-Disposition: attachment; filename="${body.zipName || 'SagasonLote.zip'}"`,
                    `Content-Transfer-Encoding: base64`,
                    ``,
                    body.zipBase64.match(/.{1,76}/g).join('\r\n'), 
                    ``,
                    `--${boundary}--`
                ].join('\r\n');
                
                await sesClient.send(new SendRawEmailCommand({ RawMessage: { Data: Buffer.from(rawMessage) } }));
            } else {
                // Fallback sin adjunto
                await sesClient.send(new SendEmailCommand({
                    Source: "Fábrica Sagason <no-reply@sagason.cl>",
                    Destination: { ToAddresses: [adminEmail] },
                    Message: { Subject: { Data: "Respaldo: Códigos QR Sagason Generados" }, Body: { Html: { Data: htmlContent } } }
                }));
            }
            return { statusCode: 200, headers: { "Access-Control-Allow-Origin": "*" }, body: JSON.stringify({ success: true }) };
        } catch (error) {
            console.error(error);
            return { statusCode: 500, headers: { "Access-Control-Allow-Origin": "*" }, body: JSON.stringify({ error: "Fallo envío de correo" }) };
        }
    }

    // ── Acción: envío diferido del correo de escaneo ─────────────────────────
    // Disparado por el frontend cuando: pasan 15s sin acción O el rescatista cierra la página
    if (action === "scan_auto") {
        try {
            const res2 = await docClient.send(new GetCommand({ TableName: "SagasonTags", Key: { tagId } }));
            const tag2 = res2.Item;
            if (!tag2) return { statusCode: 404, headers: { "Access-Control-Allow-Origin": "*" }, body: "Tag no encontrado" };

            // ps puede ser null si SagasonScanProcessor aún no fue actualizado — aún así enviamos
            const ps = tag2.pending_scan || {};

            // Solo omitir si explícitamente cancelado o ya notificado
            if (ps.cancelled === true || ps.notified === true) {
                console.log("[scan_auto] Omitido:", ps.cancelled ? "cancelado" : "ya notificado");
                return { statusCode: 200, headers: { "Access-Control-Allow-Origin": "*" }, body: JSON.stringify({ status: "SKIPPED" }) };
            }

            // Marcar como notificado ANTES de enviar (evita condición de carrera doble llamada)
            // Usamos SET completo para evitar error si pending_scan no existe como Map en DynamoDB
            await docClient.send(new UpdateCommand({
                TableName: "SagasonTags",
                Key: { tagId },
                UpdateExpression: "SET pending_scan = :ps",
                ExpressionAttributeValues: { ":ps": { ...ps, notified: true, timestamp: ps.timestamp || Date.now() } }
            }));

            if (tag2.email_1 && tag2.notify_scan !== false) {
                await sendScanEmail(tag2.email_1, tag2.nickname, ps);
                console.log("[scan_auto] Correo enviado a:", tag2.email_1);
            }

            // ── NUEVO: PUSH PARA SCAN_AUTO ──
            try {
                const ownerRes = await docClient.send(new GetCommand({
                    TableName: "SagasonOwners",
                    Key: { ownerId: "431c7a3a-9091-701f-8743-984f2a00482d" }
                }));
                const rawToken = ownerRes.Item?.pushToken;
                if (rawToken) {
                    let tokens = Array.isArray(rawToken) ? rawToken : [rawToken];
                    tokens = [...new Set(tokens.filter(t => t))];
                    if (tokens.length > 0) {
                        const tagNick = tag2 ? tag2.nickname : "Tu Tag";
                        await fetch('https://exp.host/--/api/v2/push/send', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                                to: tokens,
                                title: `🚨 Escaneo: ${tagNick}`,
                                body: `Tu placa ha sido escaneada (automático).`,
                                sound: 'default',
                                data: {
                                    tagId,
                                    tagNickname: tagNick,
                                    reportName: "Anónimo",
                                    reportPhone: "No entregado",
                                    reportMessage: "Escaneo automático (15s)",
                                    locationName: ps.location || "Ubicación aproximada",
                                    latitude: ps.mapsLink ? ps.mapsLink.split('q=')[1]?.split(',')[0] : '0',
                                    longitude: ps.mapsLink ? ps.mapsLink.split('q=')[1]?.split(',')[1] : '0'
                                }
                            })
                        });
                    }
                }
            } catch (pErr) { console.error("Error push scan_auto:", pErr); }

            return { statusCode: 200, headers: { "Access-Control-Allow-Origin": "*" }, body: JSON.stringify({ status: "SCAN_EMAIL_SENT" }) };
        } catch (e) {
            console.error("[scan_auto] Error:", e);
            return { statusCode: 500, headers: { "Access-Control-Allow-Origin": "*" }, body: JSON.stringify({ error: "Error Server" }) };
        }
    }

    try {
        const res = await docClient.send(new GetCommand({ TableName: "SagasonTags", Key: { tagId } }));
        const tag = res.Item;
        if (!tag) return { statusCode: 404, headers: { "Access-Control-Allow-Origin": "*" }, body: "Error" };

        const isScanEvent = !name && !phone && !message;

        if (isScanEvent && tag.notify_scan === false) {
            return { statusCode: 200, headers: { "Access-Control-Allow-Origin": "*" }, body: JSON.stringify({ status: "IGNORED_BY_USER_SETTINGS_SCAN" }) };
        }
        if (!isScanEvent && tag.notify_form === false) {
             return { statusCode: 200, headers: { "Access-Control-Allow-Origin": "*" }, body: JSON.stringify({ status: "IGNORED_BY_USER_SETTINGS_FORM" }) };
        }

        // ── Cancelar el correo de escaneo pendiente ────────────────────────────
        // El rescatista presionó un botón → llega un reporte completo → el correo
        // de escaneo ya no es necesario, evitar correo duplicado.
        if (tag.pending_scan && !tag.pending_scan.notified && !tag.pending_scan.cancelled) {
            try {
                await docClient.send(new UpdateCommand({
                    TableName: "SagasonTags",
                    Key: { tagId },
                    UpdateExpression: "SET pending_scan.cancelled = :t",
                    ExpressionAttributeValues: { ":t": true }
                }));
            } catch (cancelErr) { console.warn("[cancel_scan] No se pudo cancelar:", cancelErr); }
        }

        const tier = tag.tier || "Free";
        const count = tag.scan_count || 0;
        const limit = tier === "Advanced" ? 60 : (tier === "Basic" ? 30 : 5);
        
        // URL de Google Maps interactivo (para el enlace)
        const mapsLink = location ? `https://www.google.com/maps?q=${location.lat},${location.lng}` : null;
        
        // URL de Google Static Maps con pin personalizado de Sagason
        let staticMapUrl = null;
        if (location && MAPS_API_KEY) {
            const lat = location.lat;
            const lng = location.lng;
            const pinIcon = encodeURIComponent("https://sagason.cl/map-pin.png");
            // Mapa estándar sin estilos personalizados para máxima compatibilidad
            staticMapUrl = `https://maps.googleapis.com/maps/api/staticmap?center=${lat},${lng}&zoom=15&size=600x300&scale=2&maptype=roadmap&markers=icon:${pinIcon}%7C${lat},${lng}&key=${MAPS_API_KEY}`;
        }
        
        const maps = mapsLink || "No compartida";
        let statusResponse = "OK";

        // ── NUEVO: PUSH PARA REPORTE MANUAL (Siempre se envía, incluso si no hay saldo) ──
        try {
            const ownerRes = await docClient.send(new GetCommand({
                TableName: "SagasonOwners",
                Key: { ownerId: "431c7a3a-9091-701f-8743-984f2a00482d" }
            }));
            const rawToken = ownerRes.Item?.pushToken;
            if (rawToken) {
                let tokens = Array.isArray(rawToken) ? rawToken : [rawToken];
                tokens = [...new Set(tokens.filter(t => t))];
                if (tokens.length > 0) {
                    const tagNick = tag ? tag.nickname : "Tu Tag";
                    await fetch('https://exp.host/--/api/v2/push/send', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            to: tokens,
                            title: `🚨 Alerta: ${tagNick}`,
                            body: `Se ha detectado actividad en tu placa.`,
                            sound: 'default',
                            data: {
                                tagId,
                                tagNickname: tagNick,
                                reportName: name || "Anónimo",
                                reportPhone: phone || "No entregado",
                                reportMessage: message || "Sin descripción",
                                locationName: maps || "Ubicación no disponible",
                                latitude: location ? location.lat.toString() : '0',
                                longitude: location ? location.lng.toString() : '0'
                            }
                        })
                    });
                }
            }
        } catch (pErr) { console.error("Error push manual:", pErr); }

        if (count >= limit) {
            if (tier === "Free") {
                await sendLimitExhaustedEmail(tag.email_1, tag.nickname, true);
                return { 
                    statusCode: 403, 
                    headers: { "Access-Control-Allow-Origin": "*" },
                    body: JSON.stringify({ error: "LIMIT_REACHED_FREE" }) 
                };
            } else {
                await sendAlertEmail([tag.email_1], tag.nickname, name, phone, message, maps, true, staticMapUrl);
                if (tier !== "Free" && tag.phone_1) {
                    await sendWhatsAppAlert([tag.phone_1], tag.nickname, maps, name, phone, message); 
                }
                statusResponse = "DEGRADED";
            }
        } else {
            const recipients = [tag.email_1, tag.email_2, tag.email_3].filter(e => e);
            await sendAlertEmail(recipients, tag.nickname, name, phone, message, maps, false, staticMapUrl);
            
            const waRecipients = [];
            if (tier !== "Free") { 
                if (tag.phone_1) waRecipients.push(tag.phone_1);
                if (tier === "Advanced") {
                    if (tag.phone_2) waRecipients.push(tag.phone_2);
                    if (tag.phone_3) waRecipients.push(tag.phone_3);
                }
            }
            if (waRecipients.length > 0) {
                await sendWhatsAppAlert(waRecipients, tag.nickname, maps, name, phone, message); 
            }

            if (count + 1 === Math.floor(limit * 0.8)) {
                await send80PercentWarning(tag.email_1, tag.nickname, count + 1, limit);
            }
        }

        await docClient.send(new UpdateCommand({
            TableName: "SagasonTags",
            Key: { tagId },
            UpdateExpression: "SET scan_count = if_not_exists(scan_count, :zero) + :inc",
            ExpressionAttributeValues: { ":zero": 0, ":inc": 1 }
        }));

        return { statusCode: 200, headers: { "Access-Control-Allow-Origin": "*" }, body: JSON.stringify({ status: statusResponse }) };

    } catch (e) { 
        console.error(e); 
        return { statusCode: 500, headers: { "Access-Control-Allow-Origin": "*" }, body: JSON.stringify({ error: "Error Server" }) }; 
    }
};

// --- API HTTPS NATIVA PARA WHATSAPP (TEXTO LIBRE, MUESTRA TUS DATOS COMPLETOS) ---
async function sendWhatsAppAlert(phones, nick, maps, infName, infPhone, msg) {
    // Formateamos un mensaje completo con estilo Whatsapp
    const messageBody = `🚨 *ALERTA SAGASON* 🚨
Tu placa "${nick}" ha sido reportada.

*Informante:* ${infName || "Anónimo"}
*Contacto:* ${infPhone || "No entregado"}
*Mensaje:* ${msg || "Sin descripción"}
📍 *Ubicación:* ${maps}

_*(Aviso: Este es un sistema automatizado. Por favor no respondas a este mensaje ya que no es monitoreado).*_`;

    for (const phone of phones) {
        if (!phone) continue;
        
        let p = phone.trim();
        if (!p.startsWith('+')) {
            p = '+' + p.replace(/[^0-9]/g, '');
        }

        // Usamos el campo Body libre en vez de ContentSid
        const postData = new URLSearchParams({
            To: `whatsapp:${p}`,
            From: TWILIO_FROM_PHONE,
            Body: messageBody
        }).toString();

        const options = {
            hostname: 'api.twilio.com',
            port: 443,
            path: `/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/Messages.json`,
            method: 'POST',
            headers: {
                'Authorization': 'Basic ' + Buffer.from(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`).toString('base64'),
                'Content-Type': 'application/x-www-form-urlencoded',
                'Content-Length': Buffer.byteLength(postData)
            }
        };

        await new Promise((resolve) => {
            const req = https.request(options, (res) => {
                let data = '';
                res.on('data', (chunk) => { data += chunk; });
                res.on('end', () => {
                    try {
                        const json = JSON.parse(data);
                        if (res.statusCode >= 200 && res.statusCode < 300) {
                            console.log(`[WA SUCCESS] Enviado a ${p} | SID: ${json.sid || 'ok'}`);
                        } else {
                            console.error(`[WA DENIED] Rechazado para ${p}:`, json);
                        }
                    } catch (e) { console.error("Error parseando Twilio:", data); }
                    resolve();
                });
            });

            req.on('error', (e) => {
                console.error(`[WA FATAL] Error de red para ${p}:`, e);
                resolve();
            });

            req.write(postData);
            req.end();
        });
    }
}

// --- FUNCIONES DE EMAILS (SIN CAMBIOS) ---
async function sendAlertEmail(to, nick, infName, infPhone, msg, maps, isDegraded, staticMapUrl) {
    const isScan = (!infName && !infPhone && !msg);
    const typeEvent = isScan
        ? "Se ha detectado un escaneo de la placa. El propietario ha sido alertado autom\u00e1ticamente."
        : "El rescatista ha completado el formulario de contacto. Revisa los datos a continuaci\u00f3n y resp\u00f3ndele a la brevedad.";

    const mapBlock = staticMapUrl
        ? `<div style="margin:20px 0; text-align:center;">
               <a href="${maps}" target="_blank" style="display:inline-block;">
                   <img src="${staticMapUrl}" alt="Ver ubicación en mapa" width="600" style="max-width:100%; border-radius:12px; border:2px solid #0ea5e9; display:block;"/>
               </a>
               <p style="font-size:12px; color:#64748b; margin-top:6px;">📍 Haz clic en el mapa para ver la ubicación exacta en Google Maps</p>
           </div>`
        : maps !== "No compartida"
            ? `<p>📍 <a href="${maps}" style="color:#0ea5e9;">Ver ubicación en Google Maps</a></p>`
            : `<p style="color:#64748b;">📍 Ubicación no compartida</p>`;

    let footerText = isDegraded
        ? `<div style="margin-top:16px; padding:12px; background:#1a0000; border:1px solid #ef4444; border-radius:8px;">
               <b style='color:#ef4444;'>⚠️ ATENCIÓN: Has superado el límite de tu plan. Solo este correo ha sido notificado. Renueva tu plan para reactivar todos tus contactos.</b>
           </div>` : "";

    footerText += `<p style="margin-top:24px; font-size:11px; color:#64748b; border-top:1px solid #1e293b; padding-top:12px;">
        <em>Aviso: Mensaje automático del sistema Sagason. Los correos enviados a esta dirección no son monitoreados. Comunícate directamente con el informante si dejó datos de contacto.</em>
    </p>`;

    const htmlBody = `
    <!DOCTYPE html>
    <html lang="es">
    <head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
    <body style="margin:0; padding:0; background:#0f172a; font-family:'Helvetica Neue',Arial,sans-serif; color:#f8fafc;">
        <table width="100%" cellpadding="0" cellspacing="0" style="max-width:640px; margin:0 auto; padding:24px 12px;">
            <tr><td>
                <!-- Header -->
                <table width="100%" cellpadding="0" cellspacing="0" style="background:#1e293b; border-radius:16px 16px 0 0; padding:20px 24px; border-bottom:2px solid #0ea5e9;">
                    <tr>
                        <td><img src="https://sagason.cl/logo-chico.png" height="32" alt="Sagason"/></td>
                        <td style="text-align:right; font-size:11px; color:#64748b;">Sistema de Alertas Sagason</td>
                    </tr>
                </table>
                <!-- Body -->
                <table width="100%" cellpadding="0" cellspacing="0" style="background:#1e293b; padding:24px;">
                    <tr><td>
                        <h2 style="margin:0 0 4px; font-size:20px; color:#0ea5e9;">✅ Reporte: ${nick}</h2>
                        <p style="margin:0 0 20px; font-size:14px; color:#94a3b8;">${typeEvent}</p>
                        
                        <table width="100%" cellpadding="8" cellspacing="0" style="background:#0f172a; border-radius:10px; font-size:14px; margin-bottom:20px;">
                            <tr><td style="color:#64748b; white-space:nowrap; width:110px;">&#128100; Informante</td><td style="color:#f8fafc; word-break:break-word;">${infName || "<em style='color:#475569;'>An&#243;nimo</em>"}</td></tr>
                            <tr style="border-top:1px solid #1e293b;"><td style="color:#64748b; white-space:nowrap; width:110px;">&#128222; Contacto</td><td style="color:#f8fafc; word-break:break-word;">${infPhone || "<em style='color:#475569;'>No entregado</em>"}</td></tr>
                            <tr style="border-top:1px solid #1e293b;"><td style="color:#64748b; white-space:nowrap; width:110px; vertical-align:top;">&#128172; Mensaje</td><td style="color:#f8fafc; word-break:break-word; white-space:pre-wrap;">${msg || "<em style='color:#475569;'>Sin descripci&#243;n</em>"}</td></tr>
                        </table>
                        
                        ${mapBlock}
                        ${footerText}
                    </td></tr>
                </table>
                <!-- Footer -->
                <table width="100%" cellpadding="0" cellspacing="0" style="background:#0f172a; border-radius:0 0 16px 16px; padding:14px 24px; text-align:center;">
                    <tr><td style="font-size:11px; color:#334155;">sagason.cl &nbsp;|&nbsp; no-reply@sagason.cl</td></tr>
                </table>
            </td></tr>
        </table>
    </body>
    </html>`;

    await sesClient.send(new SendEmailCommand({
        Source: "Sagason Alertas <no-reply@sagason.cl>",
        Destination: { ToAddresses: to },
        Message: {
            Subject: { Data: `✅ REPORTE SAGASON: ${nick}` },
            Body: { Html: { Data: htmlBody } }
        }
    }));
}

async function sendLimitExhaustedEmail(to, nick, isFree) {
    await sesClient.send(new SendEmailCommand({ Source: "no-reply@sagason.cl", Destination: { ToAddresses: [to] }, Message: { Subject: { Data: `❌ SERVICIO SUSPENDIDO: ${nick}` }, Body: { Html: { Data: `<h3>Límite de alertas alcanzado</h3><p>Tu tag <b>${nick}</b> ha intentado ser reportado pero has agotado tus créditos anuales. Para seguir protegido, por favor renueva tu suscripción o mejora tu plan en el dashboard.</p>` } } } }));
}

async function send80PercentWarning(to, nick, current, limit) {
    await sesClient.send(new SendEmailCommand({ Source: "no-reply@sagason.cl", Destination: { ToAddresses: [to] }, Message: { Subject: { Data: `⚠️ AVISO DE CONSUMO: ${nick}` }, Body: { Html: { Data: `Tu tag ha alcanzado el 80% de su límite anual (${current}/${limit}). Evita quedar desprotegido renovando tu plan hoy.` } } } }));
}

// ══════════════════════════════════════════════════════════════════════════════
// Correo de "Escaneo en Tránsito" — disparado de forma diferida desde el frontend
// Los datos del dispositivo/IP vienen del objeto pending_scan guardado por /scan
// ══════════════════════════════════════════════════════════════════════════════
async function sendScanEmail(to, nick, ps) {
    const mapBlock = ps.mapsLink
        ? `<tr style="border-top:1px solid #1e293b;">
               <td colspan="2" style="padding:8px;">
                   <a href="${ps.mapsLink}" target="_blank"
                      style="font-size:13px; color:#0ea5e9; text-decoration:none;">
                       &#128205; Ver ubicaci&#243;n aproximada en Google Maps
                   </a>
               </td>
           </tr>`
        : "";

    const htmlBody = `
<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0; padding:0; background:#0f172a; font-family:'Helvetica Neue',Arial,sans-serif; color:#f8fafc;">
    <table width="100%" cellpadding="0" cellspacing="0" style="max-width:640px; margin:0 auto; padding:24px 12px;">
        <tr><td>
            <!-- Header -->
            <table width="100%" cellpadding="0" cellspacing="0"
                   style="background:#1e293b; border-radius:16px 16px 0 0; padding:20px 24px; border-bottom:2px solid #f59e0b;">
                <tr>
                    <td><img src="https://sagason.cl/logo-chico.png" height="32" alt="Sagason"/></td>
                    <td style="text-align:right; font-size:11px; color:#64748b;">Sistema de Alertas Sagason</td>
                </tr>
            </table>
            <!-- Body -->
            <table width="100%" cellpadding="0" cellspacing="0" style="background:#1e293b; padding:24px;">
                <tr><td>
                    <h2 style="margin:0 0 4px; font-size:20px; color:#f59e0b;">&#9888;&#65039; Escaneo en tr&#225;nsito: ${nick}</h2>
                    <p style="margin:0 0 20px; font-size:14px; color:#94a3b8;">
                        Tu placa acaba de ser escaneada. El rescatista cerr&#243; la p&#225;gina sin enviar datos de contacto,
                        pero podría volver. Mant&#233;n atenci&#243;n a comunicaciones futuras.
                    </p>
                    <!-- Detalles técnicos -->
                    <table width="100%" cellpadding="8" cellspacing="0"
                           style="background:#0f172a; border-radius:10px; font-size:14px; margin-bottom:20px;">
                        <tr>
                            <td colspan="2" style="color:#f59e0b; font-size:11px; font-weight:700;
                                text-transform:uppercase; letter-spacing:.05em; padding-bottom:4px;">
                                Detalles t&#233;cnicos del esc&#225;ner (an&#243;nimo)
                            </td>
                        </tr>
                        <tr style="border-top:1px solid #1e293b;">
                            <td style="color:#64748b; white-space:nowrap; width:160px;">&#128205; Ubicaci&#243;n aprox.</td>
                            <td style="color:#f8fafc; word-break:break-word;">${ps.location || "No disponible"}</td>
                        </tr>
                        <tr style="border-top:1px solid #1e293b;">
                            <td style="color:#64748b; white-space:nowrap;">&#127760; Red / Empresa IP</td>
                            <td style="color:#f8fafc;">${ps.isp || "No detectado"}</td>
                        </tr>
                        <tr style="border-top:1px solid #1e293b;">
                            <td style="color:#64748b; white-space:nowrap;">&#128187; Dispositivo</td>
                            <td style="color:#f8fafc;">${ps.device || "Desconocido"}</td>
                        </tr>
                        <tr style="border-top:1px solid #1e293b;">
                            <td style="color:#64748b; white-space:nowrap;">&#127758; Idioma</td>
                            <td style="color:#f8fafc;">${ps.language || "No detectado"}</td>
                        </tr>
                        ${mapBlock}
                    </table>
                    <!-- Nota -->
                    <div style="background:rgba(245,158,11,0.08); border:1px solid rgba(245,158,11,0.25);
                                border-radius:10px; padding:14px 16px; font-size:13px; color:#fbbf24; line-height:1.55;">
                        &#8987; El rescatista cerr&#243; la p&#225;gina sin compartir sus datos de contacto.
                        Si tienes informaci&#243;n visible en la placa, es posible que intente contactarte por otra v&#237;a.
                    </div>
                    <p style="margin-top:24px; font-size:11px; color:#64748b; border-top:1px solid #1e293b; padding-top:12px;">
                        <em>Aviso: Mensaje autom&#225;tico del sistema Sagason. Los correos enviados a esta direcci&#243;n no son monitoreados.</em>
                    </p>
                </td></tr>
            </table>
            <!-- Footer -->
            <table width="100%" cellpadding="0" cellspacing="0"
                   style="background:#0f172a; border-radius:0 0 16px 16px; padding:14px 24px; text-align:center;">
                <tr><td style="font-size:11px; color:#334155;">sagason.cl &nbsp;|&nbsp; no-reply@sagason.cl</td></tr>
            </table>
        </td></tr>
    </table>
</body>
</html>`;

    await sesClient.send(new SendEmailCommand({
        Source: "Sagason Alertas <no-reply@sagason.cl>",
        Destination: { ToAddresses: [to] },
        Message: {
            Subject: { Data: `⚠️ ESCANEO EN TRÁNSITO: ${nick}` },
            Body: { Html: { Data: htmlBody } }
        }
    }));
}
