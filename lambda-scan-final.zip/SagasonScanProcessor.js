import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand, UpdateCommand } from "@aws-sdk/lib-dynamodb";
import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";

const dbClient = new DynamoDBClient({ region: "sa-east-1" });
const docClient = DynamoDBDocumentClient.from(dbClient);
const sesClient = new SESClient({ region: "sa-east-1" });

const headers = { 
    "Access-Control-Allow-Origin": "*", 
    "Access-Control-Allow-Headers": "Content-Type,Authorization", 
    "Access-Control-Allow-Methods": "GET,OPTIONS" 
};

export const handler = async (event) => {
    if (event.requestContext?.http?.method === "OPTIONS") return { statusCode: 204, headers };

    const tagId = event.queryStringParameters?.id;
    if (!tagId) return { statusCode: 400, headers, body: "Falta ID" };

    try {
        const res = await docClient.send(new GetCommand({ TableName: "SagasonTags", Key: { tagId } }));
        const tag = res.Item;
        if (!tag || tag.status !== "Activo") return { statusCode: 404, headers, body: "Tag no encontrado" };

        // ══════════════════════════════════════════════════════════════
        // 1. RECOPILAR DATOS DEL ESCANEO (pasivos, sin permiso)
        // ══════════════════════════════════════════════════════════════
        let locationText = "Ubicación aproximada no disponible";
        let ispText      = "No detectado";
        let mapsLink     = null;

        // Coordenadas enviadas por el frontend (query params ?lat=...&lng=...)
        const qLat = event.queryStringParameters?.lat;
        const qLng = event.queryStringParameters?.lng;
        if (qLat && qLng) {
            mapsLink = `https://www.google.com/maps?q=${qLat},${qLng}`;
        }

        // Geolocalización por IP
        const ip = event.headers?.['cf-connecting-ip'] || 
                   event.headers?.['x-forwarded-for']?.split(',')[0]?.trim() || 
                   event.requestContext?.http?.sourceIp;

        if (ip) {
            try {
                const geoRes  = await fetch(`http://ip-api.com/json/${ip}?fields=status,city,regionName,country,isp`);
                const geoData = await geoRes.json();
                if (geoData.status === "success") {
                    locationText = `${geoData.city}, ${geoData.regionName}, ${geoData.country}`;
                    ispText      = geoData.isp || "No detectado";
                    if (!mapsLink) mapsLink = `https://www.google.com/maps/search/${encodeURIComponent(locationText)}`;
                }
            } catch (err) { console.error("Error geo IP:", err); }
        }

        const userAgent = event.headers?.['user-agent'] || "Desconocido";
        let   deviceType = "Desconocido";
        if      (userAgent.includes("iPhone"))  deviceType = "iPhone (Apple)";
        else if (userAgent.includes("Mac OS"))  deviceType = "Mac (Apple)";
        else if (userAgent.includes("Android")) deviceType = "Dispositivo Android";
        else if (userAgent.includes("Windows")) deviceType = "PC Windows";

        const acceptLanguage = event.headers?.['accept-language']?.split(',')[0] || "No detectado";

        // ══════════════════════════════════════════════════════════════
        // 2. GUARDAR DATOS EN DYNAMODB (sin enviar correo todavía)
        //    El frontend decidirá cuándo disparar el correo:
        //    - Si el rescatista cierra la página antes de 15s → sendBeacon
        //    - Si pasan 15s sin acción → fetch normal
        //    - Si presiona un botón → /report cancela este pending y envía el suyo
        // ══════════════════════════════════════════════════════════════
        if (tag.notify_scan !== false) {
            const pendingScan = {
                device:    deviceType,
                isp:       ispText,
                location:  locationText,
                language:  acceptLanguage,
                mapsLink:  mapsLink || null,
                timestamp: Date.now(),
                notified:  false,
                cancelled: false
            };

            await docClient.send(new UpdateCommand({
                TableName: "SagasonTags",
                Key: { tagId },
                UpdateExpression: "SET pending_scan = :ps",
                ExpressionAttributeValues: { ":ps": pendingScan }
            }));
        }

        // ══════════════════════════════════════════════════════════════
        // 3. DEVOLVER DATOS A LA PÁGINA WEB
        // ══════════════════════════════════════════════════════════════
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({
                nickname:   tag.nickname,
                category:   tag.category,
                thanks_msg: tag.thanks_msg || ""
            })
        };

    } catch (e) {
        console.error(e);
        return { statusCode: 500, headers, body: e.message };
    }
};
