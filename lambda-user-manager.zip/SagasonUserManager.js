import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand, PutCommand, QueryCommand } from "@aws-sdk/lib-dynamodb";

const dbClient = new DynamoDBClient({ region: "sa-east-1" });
const docClient = DynamoDBDocumentClient.from(dbClient);

const headers = { 
    "Access-Control-Allow-Origin": "*", 
    "Access-Control-Allow-Headers": "Content-Type,Authorization", 
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS" 
};

// La corrección exacta que necesitabas:
const ADMIN_EMAIL = process.env.ADMINISTRATOR_EMAIL; 

const generateSecureId = () => {
    // 1. SOLUCIÓN: Eliminamos las minúsculas. Solo MAYÚSCULAS y NÚMEROS.
    const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
    const s = () => Array.from({length: 4}, () => chars[Math.floor(Math.random() * chars.length)]).join('');
    return `${s()}-${s()}-${s()}-${s()}`;
};

export const handler = async (event) => {
    if (event.requestContext.http.method === "OPTIONS") return { statusCode: 204, headers };
    const method = event.requestContext.http.method;
    const path = event.requestContext.http.path;
    const body = event.body ? JSON.parse(event.body) : null;
    const ownerId = event.queryStringParameters?.ownerId || body?.ownerId;
    const userEmail = event.queryStringParameters?.email || body?.email;

    try {
        if (path.includes("/admin-create-tag")) {
            if (userEmail !== ADMIN_EMAIL) return { statusCode: 403, headers, body: "No autorizado" };
            const newTagId = generateSecureId();
            
            // ✅ AQUI GUARDAMOS EL PIN PARA PROTEGER LA PLACA ESTRICTAMENTE
            const newTag = { 
                tagId: newTagId, 
                ownerId: "DISPONIBLE", 
                activationCode: body.activationCode || "N/A", // Guarda el PIN generado
                nickname: body.nickname || "Nuevo Producto", 
                category: "Equipos", 
                country: body.country || "Chile",
                donated: body.donated === true,
                donated_by: body.donated_by || "",
                status: "Inactivo", 
                tier: "Free", 
                scan_count: 0, 
                createdAt: new Date().toISOString() 
            };
            await docClient.send(new PutCommand({ TableName: "SagasonTags", Item: newTag }));
            return { statusCode: 200, headers, body: JSON.stringify({ tagId: newTagId, activationCode: body.activationCode }) };
        }

        if (path.includes("/user-tags")) {
            const action = event.queryStringParameters?.action;
            const profileId = "PROFILE#" + ownerId;

            if (action === "profile") {
                if (method === "GET") {
                    const res = await docClient.send(new GetCommand({ TableName: "SagasonTags", Key: { tagId: profileId } }));
                    return { statusCode: 200, headers, body: JSON.stringify(res.Item || {}) };
                }
                if (method === "POST") {
                    const current = await docClient.send(new GetCommand({ TableName: "SagasonTags", Key: { tagId: profileId } }));
                    const updated = { 
                        ...(current.Item || {}),
                        tagId: profileId,
                        ownerId: ownerId,
                        name: body.name || "",
                        phone: body.phone || "",
                        company: body.company || "",
                        updatedAt: new Date().toISOString()
                    };
                    await docClient.send(new PutCommand({ TableName: "SagasonTags", Item: updated }));
                    return { statusCode: 200, headers, body: JSON.stringify(updated) };
                }
            }

            if (method === "GET") {
                //... resto sin cambios para obtener la lista, pero filtramos el perfil
                const res = await docClient.send(new QueryCommand({ TableName: "SagasonTags", IndexName: "ownerId-index", KeyConditionExpression: "ownerId = :o", ExpressionAttributeValues: { ":o": ownerId } }));
                const items = (res.Items || []).filter(item => !item.tagId.startsWith("PROFILE#"));
                return { statusCode: 200, headers, body: JSON.stringify(items) };
            }
            if (method === "POST") {
                const rawTagId = body.tagId.trim();
                let check = await docClient.send(new GetCommand({ TableName: "SagasonTags", Key: { tagId: rawTagId } }));
                
                if (!check.Item) {
                    check = await docClient.send(new GetCommand({ TableName: "SagasonTags", Key: { tagId: rawTagId.toUpperCase() } }));
                }

                const current = check.Item;
                if (!current) { return { statusCode: 404, headers, body: "El ID ingresado no coincide con ninguna placa de fábrica." }; }

                if (current.ownerId !== "DISPONIBLE" && current.ownerId !== ownerId) {
                    return { statusCode: 403, headers, body: "Esta placa ya está registrada a otro usuario." };
                }

                // ✅ AQUÍ REVISAMOS EL PIN CUANDO EL CLIENTE INTENTA REGISTRARLA
                if (current.ownerId === "DISPONIBLE" && current.activationCode && current.activationCode !== "N/A") {
                    if (body.activationCode !== current.activationCode) {
                        return { statusCode: 403, headers, body: "El Código de Activación (PIN) es inválido. Intenta de nuevo." };
                    }
                }

                const realTagId = current.tagId;
                const tier = current.tier || "Free";
                let e1 = body.email_1, e2 = "", e3 = "", p1 = "", p2 = "", p3 = "";

                if (tier === "Basic") { p1 = body.phone_1; }
                else if (tier === "Advanced") { e2 = body.email_2; e3 = body.email_3; p1 = body.phone_1; p2 = body.phone_2; p3 = body.phone_3; }

                const updated = { 
                    ...current, 
                    ownerId, 
                    tagId: realTagId, 
                    nickname: body.nickname || current.nickname, 
                    category: body.category || current.category, 
                    country: body.country || current.country || "Chile",
                    email_1: e1, 
                    email_2: e2, 
                    email_3: e3, 
                    phone_1: p1, 
                    phone_2: p2, 
                    phone_3: p3, 
                    thanks_msg: body.thanks_msg || "", 
                    tier, 
                    status: "Activo", 
                    notify_scan: body.notify_scan !== undefined ? body.notify_scan : (current.notify_scan !== undefined ? current.notify_scan : true), 
                    notify_form: body.notify_form !== undefined ? body.notify_form : (current.notify_form !== undefined ? current.notify_form : true) 
                };
                
                await docClient.send(new PutCommand({ TableName: "SagasonTags", Item: updated }));
                return { statusCode: 200, headers, body: JSON.stringify(updated) };
            }
        }
        
        if (path.includes("/user-profile")) {
            const profileId = "PROFILE#" + ownerId;
            if (method === "GET") {
                const res = await docClient.send(new GetCommand({ TableName: "SagasonTags", Key: { tagId: profileId } }));
                return { statusCode: 200, headers, body: JSON.stringify(res.Item || {}) };
            }
            if (method === "POST") {
                const current = await docClient.send(new GetCommand({ TableName: "SagasonTags", Key: { tagId: profileId } }));
                const updated = { 
                    ...(current.Item || {}),
                    tagId: profileId,
                    ownerId: ownerId,
                    name: body.name || "",
                    phone: body.phone || "",
                    company: body.company || "",
                    updatedAt: new Date().toISOString()
                };
                await docClient.send(new PutCommand({ TableName: "SagasonTags", Item: updated }));
                return { statusCode: 200, headers, body: JSON.stringify(updated) };
            }
        }

    } catch (e) { return { statusCode: 500, headers, body: e.message }; }
};

