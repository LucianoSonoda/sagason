import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand } from "@aws-sdk/lib-dynamodb";
import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";

const dbClient = new DynamoDBClient({ region: "sa-east-1" });
const docClient = DynamoDBDocumentClient.from(dbClient);
const sesClient = new SESClient({ region: "sa-east-1" });

const headers = { 
    "Access-Control-Allow-Origin": "*", 
    "Access-Control-Allow-Headers": "Content-Type,Authorization", 
    "Access-Control-Allow-Methods": "GET,OPTIONS" 
};

export const handler = async (event) => {
    if (event.requestContext?.http?.method === "OPTIONS") return { statusCode: 204, headers };

    const tagId = event.queryStringParameters?.id;
    if (!tagId) return { statusCode: 400, headers, body: "Falta ID" };

    try {
        const res = await docClient.send(new GetCommand({ TableName: "SagasonTags", Key: { tagId } }));
        const tag = res.Item;

        if (!tag || tag.status !== "Activo") {
            return { statusCode: 404, headers, body: "Tag no encontrado" };
        }

        // ==========================================
        // 1. Extraer datos pasivos del escaneo
        // ==========================================
        let locationText = "Ubicación aproximada no disponible";
        let ispText      = "No detectado";
        let mapsLink     = null;

        // Coordenadas enviadas por el frontend (query params ?lat=...&lng=...)
        const qLat = event.queryStringParameters?.lat;
        const qLng = event.queryStringParameters?.lng;
        if (qLat && qLng) {
            mapsLink = `https://www.google.com/maps?q=${qLat},${qLng}`;
        }

        // Extraer IP
        const ip = event.headers?.['cf-connecting-ip'] || 
                   event.headers?.['x-forwarded-for']?.split(',')[0]?.trim() || 
                   event.requestContext?.http?.sourceIp;

        if (ip) {
            try {
                const geoRes  = await fetch(`http://ip-api.com/json/${ip}?fields=status,city,regionName,country,isp`);
                const geoData = await geoRes.json();
                if (geoData.status === "success") {
                    locationText = `${geoData.city}, ${geoData.regionName}, ${geoData.country}`;
                    ispText      = geoData.isp || "No detectado";
                    if (!mapsLink) {
                        // fallback: enlace de texto con la ciudad
                        mapsLink = `https://www.google.com/maps/search/${encodeURIComponent(locationText)}`;
                    }
                }
            } catch (err) { console.error("Error geo IP:", err); }
        }

        const userAgent    = event.headers?.['user-agent'] || "Desconocido";
        let   deviceType   = "Desconocido";
        if      (userAgent.includes("iPhone"))  deviceType = "iPhone (Apple)";
        else if (userAgent.includes("Mac OS"))  deviceType = "Mac (Apple)";
        else if (userAgent.includes("Android")) deviceType = "Dispositivo Android";
        else if (userAgent.includes("Windows")) deviceType = "PC Windows";

        const acceptLanguage = event.headers?.['accept-language']?.split(',')[0] || "No detectado";

        // ==========================================
        // 2. Notificación al dueño — diseño unificado
        // ==========================================
        if (tag.email_1 && tag.notify_scan !== false) {

            const mapBlock = mapsLink
                ? `<tr><td colspan="2" style="padding:0 8px 12px;">
                       <a href="${mapsLink}" target="_blank"
                          style="display:inline-block; font-size:13px; color:#0ea5e9; text-decoration:none;">
                           &#128205; Ver ubicaci&#243;n aproximada en Google Maps
                       </a>
                   </td></tr>`
                : "";

            const htmlBody = `
<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0; padding:0; background:#0f172a; font-family:'Helvetica Neue',Arial,sans-serif; color:#f8fafc;">
    <table width="100%" cellpadding="0" cellspacing="0" style="max-width:640px; margin:0 auto; padding:24px 12px;">
        <tr><td>

            <!-- Header -->
            <table width="100%" cellpadding="0" cellspacing="0"
                   style="background:#1e293b; border-radius:16px 16px 0 0; padding:20px 24px; border-bottom:2px solid #f59e0b;">
                <tr>
                    <td><img src="https://sagason.cl/logo-chico.png" height="32" alt="Sagason"/></td>
                    <td style="text-align:right; font-size:11px; color:#64748b;">Sistema de Alertas Sagason</td>
                </tr>
            </table>

            <!-- Body -->
            <table width="100%" cellpadding="0" cellspacing="0" style="background:#1e293b; padding:24px;">
                <tr><td>
                    <h2 style="margin:0 0 4px; font-size:20px; color:#f59e0b;">&#9888;&#65039; Escaneo en tr&#225;nsito: ${tag.nickname}</h2>
                    <p style="margin:0 0 20px; font-size:14px; color:#94a3b8;">
                        Tu placa acaba de ser escaneada. Mantente atento a pr&#243;ximas comunicaciones del rescatista.
                    </p>

                    <!-- Detalles técnicos -->
                    <table width="100%" cellpadding="8" cellspacing="0"
                           style="background:#0f172a; border-radius:10px; font-size:14px; margin-bottom:20px;">
                        <tr>
                            <td colspan="2" style="color:#f59e0b; font-size:11px; font-weight:700;
                                text-transform:uppercase; letter-spacing:.05em; padding-bottom:4px;">
                                Detalles t&#233;cnicos del esc&#225;ner (an&#243;nimo)
                            </td>
                        </tr>
                        <tr style="border-top:1px solid #1e293b;">
                            <td style="color:#64748b; white-space:nowrap; width:160px;">&#128205; Ubicaci&#243;n aprox.</td>
                            <td style="color:#f8fafc; word-break:break-word;">${locationText}</td>
                        </tr>
                        <tr style="border-top:1px solid #1e293b;">
                            <td style="color:#64748b; white-space:nowrap;">&#127760; Red / Empresa IP</td>
                            <td style="color:#f8fafc;">${ispText}</td>
                        </tr>
                        <tr style="border-top:1px solid #1e293b;">
                            <td style="color:#64748b; white-space:nowrap;">&#128187; Dispositivo</td>
                            <td style="color:#f8fafc;">${deviceType}</td>
                        </tr>
                        <tr style="border-top:1px solid #1e293b;">
                            <td style="color:#64748b; white-space:nowrap;">&#127758; Idioma</td>
                            <td style="color:#f8fafc;">${acceptLanguage}</td>
                        </tr>
                        ${mapBlock}
                    </table>

                    <!-- Nota de espera -->
                    <div style="background:rgba(245,158,11,0.08); border:1px solid rgba(245,158,11,0.25);
                                border-radius:10px; padding:14px 16px; font-size:13px; color:#fbbf24; line-height:1.55;">
                        &#8987; Esperando silenciosamente a que el rescatista complete el formulario
                        y comparta sus datos de contacto reales.
                    </div>

                    <!-- Footer note -->
                    <p style="margin-top:24px; font-size:11px; color:#64748b;
                              border-top:1px solid #1e293b; padding-top:12px;">
                        <em>Aviso: Mensaje autom&#225;tico del sistema Sagason.
                        Los correos enviados a esta direcci&#243;n no son monitoreados.</em>
                    </p>
                </td></tr>
            </table>

            <!-- Footer -->
            <table width="100%" cellpadding="0" cellspacing="0"
                   style="background:#0f172a; border-radius:0 0 16px 16px; padding:14px 24px; text-align:center;">
                <tr><td style="font-size:11px; color:#334155;">
                    sagason.cl &nbsp;|&nbsp; no-reply@sagason.cl
                </td></tr>
            </table>

        </td></tr>
    </table>
</body>
</html>`;

            try {
                await sesClient.send(new SendEmailCommand({
                    Source: "Sagason Alertas <no-reply@sagason.cl>",
                    Destination: { ToAddresses: [tag.email_1] },
                    Message: {
                        Subject: { Data: `⚠️ ESCANEO EN TRÁNSITO: ${tag.nickname}` },
                        Body: { Html: { Data: htmlBody } }
                    }
                }));
            } catch (e) { console.error("Error SES:", e); }
        }

        // ==========================================
        // 3. Respuesta final para la pantalla web
        // ==========================================
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({
                nickname:   tag.nickname,
                category:   tag.category,
                thanks_msg: tag.thanks_msg || ""
            })
        };

    } catch (e) {
        return { statusCode: 500, headers, body: e.message };
    }
};
